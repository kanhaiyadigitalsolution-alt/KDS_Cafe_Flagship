# KDS Café Flagship Demo
Demo brand: The Bean Courtyard Café, Pune.
Purpose: sales demo for a ₹5,000 website package.
Replace sample brand, address, phone, menu, prices and images with the real client's content.
Important: sample ratings/testimonials are not real proof and must not be presented as client reviews.
